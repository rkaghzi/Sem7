def lcs(X, Y):
    m, n = len(X), len(Y)
    dp = [[0]*(n+1) for _ in range(m+1)]

    for i in range(1, m+1):
        for j in range(1, n+1):
            if X[i-1] == Y[j-1]:
                dp[i][j] = dp[i-1][j-1] + 1
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])

    return dp, dp[m][n]

# Q1
X1 = "ABCBDAB"
Y1 = "BDCABA"
table1, length1 = lcs(X1, Y1)
print("LCS Length (Q1):", length1)

# Q2
X2 = "AXYT"
Y2 = "AYZX"
table2, length2 = lcs(X2, Y2)
print("LCS Length (Q2):", length2)
