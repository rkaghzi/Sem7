def knapsack(W, wt, val, n):
    dp = [[0]*(W+1) for _ in range(n+1)]

    for i in range(1, n+1):
        for w in range(1, W+1):
            if wt[i-1] <= w:
                dp[i][w] = max(val[i-1] + dp[i-1][w-wt[i-1]],
                               dp[i-1][w])
            else:
                dp[i][w] = dp[i-1][w]
    return dp


W = 8
wt = [2, 4, 6]
val = [10, 20, 30]
n = 3

dp = knapsack(W, wt, val, n)
print("Maximum Knapsack Value:", dp[n][W])
