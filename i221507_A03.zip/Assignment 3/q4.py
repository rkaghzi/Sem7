# ---------------------------------------------------------
# LPS Table Function (Used in Q4 and Q5)
# ---------------------------------------------------------
def compute_lps(pattern):
    lps = [0] * len(pattern)
    length = 0
    i = 1

    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
    return lps


# ---------------------------------------------------------
# Q4 – KMP Search (with detailed step-by-step prints)
# ---------------------------------------------------------
def kmp_search_verbose(text, pattern):
    print(f"\n=== KMP SEARCH ===")
    print(f"Text    : {text}")
    print(f"Pattern : {pattern}")
    print("-----------------------------")

    lps = compute_lps(pattern)
    print("LPS Table:", lps)

    i = j = 0  # i = text index, j = pattern index

    while i < len(text):
        print(f"\nComparing text[{i}] = '{text[i]}' with pattern[{j}] = '{pattern[j]}'")

        if text[i] == pattern[j]:
            print(" -> Match, move both pointers")
            i += 1
            j += 1

        if j == len(pattern):
            print(f"Pattern found at index {i - j}")
            j = lps[j - 1]

        elif i < len(text) and text[i] != pattern[j]:
            print(" -> Mismatch")
            if j != 0:
                print(f"    Using LPS, jump pattern index from {j} to {lps[j - 1]}")
                j = lps[j - 1]
            else:
                print("    j = 0, move text pointer")
                i += 1


# ---------------------------------------------------------
# Q5 – Verbose LPS Builder for Step-by-Step Explanation
# ---------------------------------------------------------
def compute_lps_verbose(pattern):
    print(f"\n=== BUILDING LPS (Step-by-step) for Pattern: {pattern} ===")
    lps = [0] * len(pattern)
    length = 0  # length of previous longest prefix suffix
    i = 1

    while i < len(pattern):
        print(f"\nComparing pattern[{i}]='{pattern[i]}' with pattern[{length}]='{pattern[length]}'")

        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            print(f" -> Match: LPS[{i}] = {length}")
            i += 1
        else:
            print(" -> Mismatch")
            if length != 0:
                print(f"    Length != 0 → update length to LPS[{length - 1}] = {lps[length - 1]}")
                length = lps[length - 1]
            else:
                print(f"    Length = 0 → LPS[{i}] = 0")
                lps[i] = 0
                i += 1

    print("Final LPS:", lps)
    return lps


print("\n==================== QUESTION 4 OUTPUT ====================\n")

# Q4.1
T1 = "AAAAABAAABA"
P1 = "AAAA"
print("\n--- Q4.1 KMP for T1 & P1 ---")
kmp_search_verbose(T1, P1)

# Q4.2
T2 = "ABABDABACDABABCABAB"
P2 = "ABABCABAB"
print("\n--- Q4.2 KMP for T2 & P2 ---")
kmp_search_verbose(T2, P2)


print("\n==================== QUESTION 5 OUTPUT ====================\n")

# Q5.1
p1 = "AAACAAAA"
print("Q5.1 Pattern:", p1)
print("LPS:", compute_lps(p1), "\n")

# Q5.2
p2 = "ABABABCA"
print("Q5.2 Pattern:", p2)
print("LPS:", compute_lps(p2), "\n")

# Q5.3
p3 = "AABAACAABAA"
print("Q5.3 Pattern:", p3)
print("LPS:", compute_lps(p3), "\n")

# Q5.4 Explanation
p4 = "ABCABCD"
print("Q5.4 Pattern:", p4)
print("LPS:", compute_lps(p4))
print("\nExplanation: Characters with LPS = 0 have no prefix that matches any suffix at that point.\n")

# Q5.5 Step-by-step LPS
p5 = "ABCDABD"
print("\nQ5.5 Detailed LPS Construction:")
compute_lps_verbose(p5)

print("\n===================== END OF FILE =====================\n")
