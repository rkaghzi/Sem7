# Function to compute LPS array (KMP prefix function)
def compute_lps(pattern):
    lps = [0] * len(pattern)
    length = 0
    i = 1

    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1

    return lps


# ---------------------------------------------------------
# Q5.4 and Q5.5 require step-by-step explanation output.
# This function prints every comparison.
# ---------------------------------------------------------
def compute_lps_verbose(pattern):
    print(f"\nBuilding LPS for pattern: {pattern}")
    lps = [0] * len(pattern)
    length = 0
    i = 1

    while i < len(pattern):
        print(f"\nComparing pattern[{i}] = '{pattern[i]}' with pattern[{length}] = '{pattern[length]}'")

        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            print(f" Match → lps[{i}] = {length}")
            i += 1
        else:
            if length != 0:
                print(f" Mismatch → fallback length = lps[{length - 1}] = {lps[length - 1]}")
                length = lps[length - 1]
            else:
                print(f" Mismatch and length=0 → lps[{i}] = 0")
                lps[i] = 0
                i += 1

    print("Final LPS:", lps)
    return lps


# ---------------------------------------------------------
# Q5.1 to Q5.5
# ---------------------------------------------------------

print("\n==================== QUESTION 5 OUTPUT ====================\n")

# Q1
p1 = "AAACAAAA"
print("Q1 Pattern:", p1)
print("LPS:", compute_lps(p1))
print()

# Q2
p2 = "ABABABCA"
print("Q2 Pattern:", p2)
print("LPS:", compute_lps(p2))
print()

# Q3
p3 = "AABAACAABAA"
print("Q3 Pattern:", p3)
print("LPS:", compute_lps(p3))
print()

# Q4 Explanation: Some characters have LPS = 0
p4 = "ABCABCD"
print("Q4 Pattern:", p4)
print("LPS:", compute_lps(p4))
print("\nExplanation:")
print("Some characters have LPS = 0 because they do not start with a prefix")
print("that matches any suffix ending at that position.\n")

# Q5 Step-by-step LPS construction
p5 = "ABCDABD"
print("\nQ5 Pattern (step-by-step):", p5)
compute_lps_verbose(p5)

print("\n===================== END OF Q5 FILE =====================\n")
